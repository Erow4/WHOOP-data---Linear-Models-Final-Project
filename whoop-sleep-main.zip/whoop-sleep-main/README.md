# whoop-sleep
Does our exercise affect how well we sleep? We dig into some exercise and sleep data to answer this question.
